# Hybrid Bot: Dynamic Grid + Triangular Arbitrage (Selector)
Bu ek modüller mevcut `scan_bingx_grid.py` tarayıcınızı **canlı bot**a taşımak için başlangıç iskeletidir.

## Kurulum
```bash
pip install -r requirements.txt
cp .env.example .env  # değerleri doldurun
```

## Çalıştırma (Paper)
```bash
export $(grep -v '^#' .env | xargs)
python -m src.runner.paper_bot
```

## Yapı
- `src/core`: ccxt sarmalayıcı, risk geçidi, state, indikatörler
- `src/strategy`: `dynamic_grid.py`, `tri_arb.py`, `strategist.py`
- `src/runner`: `paper_bot.py`, `live_bot.py`

> Not: `paper_bot` şimdilik yalın bir kağıt üstü akış sunar. Mevcut tarayıcınızdaki metrikleri `strategist`'e besleyip **gerçek grid çizgilerini** `grid_sizer.py` ile üretip yerleştirmeniz önerilir.
