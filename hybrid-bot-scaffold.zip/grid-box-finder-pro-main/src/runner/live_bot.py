# Live runner is identical to paper for now, but with LIVE safety flags enforced.
# Intentionally left minimal; wire your real fills & PnL accounting here.
from .paper_bot import main

if __name__ == '__main__':
    main()
